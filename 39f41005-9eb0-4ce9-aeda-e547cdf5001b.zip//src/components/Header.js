import React from "react";

const Header = () => {
  return (
    <header>
      <h1>SIMPLE WEBSITE</h1>
    </header>
  );
};

export default Header;
